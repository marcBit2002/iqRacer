var answers = [
  {
    "id_answer": 1,
    "answer_text": "Una matriz",
    "code_answer": "A",
    "id_question": 1,
    "is_correct": 0
  },
  {
    "id_answer": 2,
    "answer_text": "PI",
    "code_answer": "B",
    "id_question": 1,
    "is_correct": 1
  },
  {
    "id_answer": 3,
    "answer_text": "Número PRT",
    "code_answer": "C",
    "id_question": 1,
    "is_correct": 0
  },
  {
    "id_answer": 4,
    "answer_text": "Un residuo",
    "code_answer": "D",
    "id_question": 1,
    "is_correct": 0
  },
  {
    "id_answer": 5,
    "answer_text": "El cielo",
    "code_answer": "A",
    "id_question": 2,
    "is_correct": 0
  },
  {
    "id_answer": 6,
    "answer_text": "El fondo marino",
    "code_answer": "B",
    "id_question": 2,
    "is_correct": 0
  },
  {
    "id_answer": 7,
    "answer_text": "La representación subterranea.",
    "code_answer": "C",
    "id_question": 2,
    "is_correct": 0
  },
  {
    "id_answer": 8,
    "answer_text": "La representación gráfica.",
    "code_answer": "D",
    "id_question": 2,
    "is_correct": 1
  },
  {
    "id_answer": 9,
    "answer_text": "Hígado",
    "code_answer": "A",
    "id_question": 3,
    "is_correct": 0
  },
  {
    "id_answer": 10,
    "answer_text": "Riñón",
    "code_answer": "B",
    "id_question": 3,
    "is_correct": 0
  },
  {
    "id_answer": 11,
    "answer_text": "Pulmón",
    "code_answer": "C",
    "id_question": 3,
    "is_correct": 0
  },
  {
    "id_answer": 12,
    "answer_text": "Páncreas",
    "code_answer": "D",
    "id_question": 3,
    "is_correct": 1
  },
];
