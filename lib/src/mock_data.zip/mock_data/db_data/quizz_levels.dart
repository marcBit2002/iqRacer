var quizzLevels = [
  {
    "id_level": 1,
    "name": "Fácil",
    "description": ""
  },
  {
    "id_level": 2,
    "name": "Intermedio",
    "description": ""
  },
  {
    "id_level": 3,
    "name": "Difícil",
    "description": ""
  },
  {
    "id_level": 4,
    "name": "Avanzado",
    "description": ""
  },
];