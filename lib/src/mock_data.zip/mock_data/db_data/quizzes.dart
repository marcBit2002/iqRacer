var quizzes = [
  {
    "id_quizz": 1,
    "name": "Historia Quizz 1",
    "id_category": 1,
    "id_level": 1,
    "num_questions": 7
  },
  // {
  //   "id_quizz": 2,
  //   "name": "",
  //   "id_category": 2,
  //   "id_level": 1,
  //   "num_questions": 7
  // },
  // {
  //   "id_quizz": 3,
  //   "name": "",
  //   "id_category": 3,
  //   "id_level": 1,
  //   "num_questions": 7
  // },
  // {
  //   "id_quizz": 4,
  //   "name": "",
  //   "id_category": 4,
  //   "id_level": 1,
  //   "num_questions": 7
  // },
];