var relationships = [
  {
    "id_user_send": 1,
    "id_user_receive": 2,
  }
];
