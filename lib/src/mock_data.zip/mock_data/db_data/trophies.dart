var trophies = [
  {
    "id_trophy": 1,
    "name": "Hista",
    "id_category": 1,
    "trophy_images": "mindful.jpeg;gopher2.jpeg"
  },
  {
    "id_trophy": 2,
    "name": "Depy",
    "id_category": 2,
    "trophy_images": "mindful.jpeg;gopher2.jpeg"
  },
  {
    "id_trophy": 3,
    "name": "Artyla",
    "id_category": 3,
    "trophy_images": "mindful.jpeg;gopher2.jpeg"
  },
  {
    "id_trophy": 4,
    "name": "Entryla",
    "id_category": 4,
    "trophy_images": "mindful.jpeg;gopher2.jpeg"
  },
  {
    "id_trophy": 5,
    "name": "Vyda",
    "id_category": 5,
    "trophy_images": "mindful.jpeg;gopher2.jpeg"
  },
  {
    "id_trophy": 6,
    "name": "Geylo",
    "id_category": 6,
    "trophy_images": "mindful.jpeg;gopher2.jpeg"
  },
  {
    "id_trophy": 7,
    "name": "Kyca",
    "id_category": 7,
    "trophy_images": "mindful.jpeg;gopher2.jpeg"
  },
  {
    "id_trophy": 8,
    "name": "Teky",
    "id_category": 8,
    "trophy_images": "mindful.jpeg;gopher2.jpeg"
  },
];