var userHistories = [
  {
    "id_user_histories": 1,
    "id_user": 1,
    "id_quizz": 1,
    "status": 1,
    "correct_answers": 7,
    "best_time": 56.73
  },
  {
    "id_user_histories": 2,
    "id_user": 2,
    "id_quizz": 1,
    "status": 1,
    "correct_answers": 10,
    "best_time": 45.62
  },
];