var userTrophies = [
  {
    "id_user_trophy": 1,
    "id_user_histories": 1,
    "id_trophy": 4,
    "latitude": 41.394209639341035,
    "longitude": 2.1280800907598505,
    "date_add": "14/12/2001 14:56:10"
  },
  {
    "id_user_trophy": 2,
    "id_user_histories": 1,
    "id_trophy": 2,
    "latitude": 41.394209639341035,
    "longitude": 2.1280800907598505,
    "date_add": "16/12/2022 18:26:17"
  },
];