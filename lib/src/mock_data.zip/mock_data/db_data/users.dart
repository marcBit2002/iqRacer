var users = [
  {
    "id": 1,
    "firstname": "Quim",
    "lastname": "Massagué",
    "email": "quim@gmail.com",
    "password": "123",
    "register_date": "2022-02-24T16:30:00",
    "id_gender": 1,
    "first_time": 0,
    "alias": "edubble",
    "user_image": "trevor-pic.webp"
  },
  {
    "id": 2,
    "firstname": "Roger",
    "lastname": "Castro",
    "email": "roger@gmail.com",
    "password": "123",
    "register_date": "2022-02-24T16:30:00",
    "id_gender": 1,
    "first_time": 0,
    "alias": "castro",
    "user_image": "trevor-pic.webp"
  },
];
